﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebWithModel.Models
{
    public static class CustomList
    {
        public static List<Student> Students = new List<Student>()
        {
            new Student{Name="Rafig",Surname="Qasimov",Phone="+994502100011"},
            new Student{Name="Memmed",Surname="Necefov",Phone="+994502100011"},
            new Student{Name="Zeynal",Surname="Zeynalli",Phone="+994502100011"},
            new Student{Name="Shems",Surname="Memmedova",Phone="+994502100011"}
        };

        public static List<Image> Images = new List<Image>()
        {
            new Image{Id=1,Link="1.jpg"},
            new Image{Id=2,Link="2.jpg"},
            new Image{Id=3,Link="3.jpg"}
        };


        public static List<Student> GetAllStudent() => Students;


    }
    public class Student
    {
        public readonly int id;
        public static int Id = 0;
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Phone { get; set; }

        public Student()
        {
            Id++;
            id = Id;
        }
    }
}
