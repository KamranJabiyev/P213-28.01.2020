﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebWithModel.Models;
using WebWithModel.ModelViews;

namespace WebWithModel.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Name = "Rafiq";
            ViewBag.Surname = "Qasimov";

            ImageStudentVM imageStudent = new ImageStudentVM()
            {
                Images = CustomList.Images,
                Students = CustomList.GetAllStudent()
            };
            return View(imageStudent);

            #region ViewBag
            //ViewBag.AllStudents = CustomList.GetAllStudent();
            //return File("~/img/1.jpg","image/jpg");
            //return Content("Salam Rafiq qaga");
            //return Json("Salam");
            //return Json(new
            //{
            //    id = 1,
            //    name = "Rafiq",
            //    group = "P213"
            //});
            #endregion
        }

        public IActionResult Details(int id)
        {
            var image = CustomList.Images.FirstOrDefault(img => img.Id == id);
            return File("~/img/" + image.Link,"image/jpg");
        }

        public IActionResult Error()
        {
            return Content("Nese sehv daxil etmisiz");
        }


    }
}